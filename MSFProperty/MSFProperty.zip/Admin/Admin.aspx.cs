﻿using System;
using System.Web.UI;

namespace MSFProperty.Admin
{
    public partial class Admin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}