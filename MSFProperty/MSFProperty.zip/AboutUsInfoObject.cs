﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MSFProperty
{
    public class AboutUsInfoObject
    {
        public string TitleText { get; set; }
        public string Quote { get; set; }
        public string Chat { get; set; }
        public string ImageUrl { get; set; }
        public Int32 ID { get; set; }

    }

}