﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MSFProperty
{
    public partial class TodoList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
  
            //TODO:  I really love the Properties page.Am I right in thinking that it will simply show the properties currently posted by us ? We can then remove them etc ?
            //TODO: Could we possibly have a black footer type thing at the bottom of each page that will have our address, email address, phone number and Letting Agent Registration Number: LARN1809015.With new legislation we have to have out letting agent registration number on all correspondence and website etc.
        }
    }
}